class Credit:

    def __init__(self):
        self._name = "Davi Ferreira do Vale"
        pass

    def getCredits(self):
        return "Updated by: "+ self._name